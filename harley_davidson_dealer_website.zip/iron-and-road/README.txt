IRON & ROAD — Motorcycle Dealer Website
========================================

Isi paket:
- index.html  : struktur halaman
- style.css   : desain responsif, layout, warna, animasi
- script.js   : navigasi mobile, filter kategori, favorit, modal test ride, validasi formulir

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka index.html di browser modern.
3. Pastikan koneksi internet aktif untuk Google Fonts dan foto Unsplash.

Catatan:
- Ini adalah konsep website dealer independen, bukan website resmi Harley-Davidson.
- Nama model dipakai sebagai contoh katalog; spesifikasi dan ketersediaan perlu dikonfirmasi dealer.
- Formulir test ride hanya demo front-end dan tidak mengirim data ke server. Hubungkan ke backend/CRM sebelum dipakai secara live.
- Ganti email hello@ironandroad.example dengan alamat kontak dealer yang sebenarnya.
